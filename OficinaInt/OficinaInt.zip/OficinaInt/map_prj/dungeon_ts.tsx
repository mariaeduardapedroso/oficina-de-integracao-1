<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="dungeon_ts" tilewidth="16" tileheight="16" tilecount="1024" columns="32">
 <image source="../assets/maps/dungeon-16-16.png" width="512" height="512"/>
</tileset>
