<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="test_tste" tilewidth="16" tileheight="16" tilecount="24" columns="6">
 <image source="../../Phaser_intro_2.02/assets/spritesheets/items.png" width="96" height="64"/>
</tileset>
